export const NavLinks = [
    {
        name: "Home",
        url: "/"
    },
    {
        name: "Services",
        url: "/services"
    },
    {
        name: "Why Us",
        url: "/whyus"
    },
    {
        name: "Learning",
        url: "/learning"
    },
    {
        name: "Pricing",
        url: "/pricing"
    },
    {
        name: "Contacts",
        url: "/contact"
    },
    {
        name: "FAQ",
        url: "/faq"
    },
];



export const HeroTexts = [
    {
        Heading: "Unleash Your Cyber Sentinel",
        Paragraph: "Discover your inner cyber sentinel! Baudspace CyberLearn equips you with the knowledge and skills to protect against digital threats. Be the guardian of your digital realm.",
        Button: "Join Now!"
    },
    {
        Heading: "Expert-Led Learning",
        Paragraph: "Learn from the best in the industry. Our expert instructors will lead you through immersive and hands-on courses, ensuring you're always one step ahead in the cybersecurity game.",
        Button: "Sign Up Today!"
    },
    {
        Heading: "Real-World Simulations",
        Paragraph: "enjoyable adventure! Join us in this fitness expedition, where fun and results go hand in hand!",
        Button: "Enroll Now!"
    },
    {
        Heading: "Secure Your Future",
        Paragraph: "Your journey with Baudspace CyberLearn is a path to securing your future in an increasingly digital world. Get started today and fortify your digital fortitude with us.",
        Button: "Enroll Now!"
    }
]


export const AboutTexts = {
    firstText: "About GymNex",
    secondText: "Welcome",
    caption: "Launch your journey to a 6-figure career that offers the chance to explore global destinations while working remotely with no technical background, IT certifications, years of experience, or a college degree!",
    paragraph1: ""}

export const Courses = {
    firstText: "What we do",
    secondText: "All Our Offer",
    list: [
        {
    caption: "Launch your journey to a 6-figure career that offers the chance to explore global destinations while working remotely with no technical background, IT certifications, years of experience, or a college degree!",
            listCaption: "Identity and Access Management (IAM)",
            text: "Our personalized approach, expert guidance, and proven results will help you achieve your fitness goals. Take the first step towards a transformed body and lifestyle today.",
        },
        {
            listCaption: "Body Building Programs",
            text: "Our expert trainers will guide you through tailored workouts, helping you achieve your bodybuilding goals efficiently and safely.",
        }
        , {
            listCaption: "Different Special Classes",
            text: "Take your workout to new heights with our high and intense Special Class, where you'll push your limits and achieve remarkable fitness results.",
        }
    ],
}

export const MembershipPlans = {
    firstText: "Pricing Tables",
    secondText: "Membership Plans",
    cards: [
        {
            amount: 8,
            duration: "day",
            caption: "One Day Training",
            benefits: ["One time access to all clubs", "Group trainer", "Book a Group class", "Fitness orientation"]
        },
        {
            amount: 49,
            duration: "month",
            caption: "12 Months Membership",
            benefits: ["Group classes", "Discuss fitness goals", "Group trainer", "Fitness orientation"]
        },
        {
            amount: 65,
            duration: "month",
            caption: "Pay Every Month",
            benefits: ["Group classes", "Discuss fitness goals", "Group trainer", "Fitness orientation"]
        }
    ]
}

export const ContactTexts = {
    firstText: "call us today",
    phone: "(+234)70-6910-6259",
    paragraph: "At our gym, you can reach out to any of our trainers to schedule a session. Home services is also within the scope of out services. Your fitness is our concern! Health is wealth!",
    button: "Schedule A Meet"
}

export const TestimonialTexts = {
    firstText: "our testimonials",
    secondText: "What Students Say",
    feedBacks: [
        {
            text: "I've been a member for six months, and the gym's supportive community and knowledgeable trainers have helped me surpass my fitness goals!",
            person: "Darrell Murray",
            type: "Student"
        },
        {
            text: "The Yoga classes have transformed my life; I feel more centered, strong, and peaceful every time I step on the mat.",
            person: "Derrick Rodriquez",
            type: "Student"
        },
        {
            text: "Attending the Special Class has been a game-changer! It's intense, but the results are incredible. Highly recommended!",
            person: "Collins Thompson",
            type: "Student"
        }
    ],
}

export const BlogTexts = {
    firstText: "Get informed",
    secondText: "Our Latest News",
    blogNews: [
        {
            caption: "Yoga",
            title: "Do your self realizations quickly fade",
            paragraph: "Discover the transformative power of yoga as we explore its numerous physical and mental benefits. From increased flexibility and strength to reduced stress and enhanced mindfulness, our yoga classes cater to practitioners of all levels. Join us on the mat and experience the harmony of mind, body, and soul.",
            time: "1m",
            author: "Ralph Cruz",
            comments: "21"
        },
        {
            caption: "Trainers & Equipment",
            title: "Little Things Do make a difference",
            paragraph: "At our gym, we take pride in our exceptional team of expert trainers who are passionate about guiding you on your fitness journey. With their knowledge and personalized approach, you'll receive the support you need to achieve your fitness goals effectively. Additionally, we offer state-of-the-art equipment that's designed to elevate your workouts and provide a holistic fitness experience like no other.",
            time: "15m",
            author: "Bruce Charles",
            comments: "45"
        },
        {
            caption: "Procrastination",
            title: "The Time is Now",
            paragraph: "Procrastination can be a common obstacle on the path to achieving our goals. In this blog, we delve into effective strategies to overcome procrastination and increase productivity. From time management techniques to staying motivated, we're here to help you take charge of your goals and embrace a more focused and fulfilling life. It's time to seize the day and make your dreams a reality!",
            time: "19m",
            author: "Steve Wagner",
            comments: "55"
        }
    ]
}

export const FooterTexts = {
    underLogoText: "We are more than just a gym; we are a passionate and supportive fitness family dedicated to helping you achieve your health and wellness goals. Our mission is to create a positive and empowering environment that inspires you to challenge yourself, embrace a healthy lifestyle, and discover the best version of yourself.",
    quickLinks: {
        caption: "Quick Links",
        links: [
            {
                name: "Home",
                url: "/"
            },
            {
                name: "About Us",
                url: "/about"
            },
            {
                name: "Schedule",
                url: "/schedule"
            },
            {
                name: "Overview",
                url: "/overview"
            },
            {
                name: "Pricing",
                url: "/pricing"
            },
            {
                name: "Contacts",
                url: "/contact"
            },
            {
                name: "FAQ",
                url: "/faq"
            },
        ]
    },
    contacts: {
        caption: "Quick Contacts",
        names: [
            {
                name: "11567 Santa Monica Blvd, Los Angeles, CA 90025, United States",
            },
            {
                name: "learn@baudspace.com",
            },
            {
                name: "+1 424-248-8496",
            }
        ]
    },
    copyright: "Copyright 2023. All Right Reserved"
}
