import Hero from "./Hero"
import Contact from "./pages/Contact"
import Faq from "./pages/Faq"
import Learning from "./pages/Learning"
import Pricing from "./pages/Pricing"
import Services from "./pages/Services"
import Whyus from "./pages/Whyus"



const Home = () => {
    return (
        <>
            <Hero />
            <Services />
            <Whyus/>
            <Learning/>
            <Pricing/>
            <Contact/>
            <Faq/>       
</>
    )
}

export default Home