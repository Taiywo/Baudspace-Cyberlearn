import React from 'react'

const Whyus = () => {
  return (
    <div>Whyus</div>
  )
}

export default Whyus