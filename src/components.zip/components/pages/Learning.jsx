import React from 'react'

const Learning = () => {
  return (
    <div>Learning</div>
  )
}

export default Learning